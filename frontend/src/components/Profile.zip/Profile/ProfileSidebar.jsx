// frontend/src/components/Profile/ProfileSidebar.jsx
import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import API, { IMG_BASE } from "../../utils/api";

// Icon imports
import dashboardIcon  from "../../assets/icons/dashboard (1).png";
import profileIcon    from "../../assets/icons/profile.png";
import reviewIcon     from "../../assets/icons/review.png";
import rewardIcon     from "../../assets/icons/reward.png";
import locationIcon   from "../../assets/icons/location.png";
import creditCardIcon from "../../assets/icons/credit-card.png";
import logoutIcon     from "../../assets/icons/icons8-logout-50.png";
import defaultAvatar  from "../../assets/profile.jpg";

const IMG_BASE_URL = IMG_BASE || "http://localhost:5000";

const makeUrl = (p) => {
  if (!p || typeof p !== "string") return null;
  if (p.startsWith("http://") || p.startsWith("https://")) return p;
  return `${IMG_BASE_URL}${p.startsWith("/") ? p : `/${p}`}`;
};

const MENU = [
  { id: "dashboard", label: "Dashboard",      icon: dashboardIcon  },
  { id: "orders",    label: "Order History",  icon: creditCardIcon },
  { id: "account",   label: "Account Details",icon: profileIcon    },
  { id: "addresses", label: "Addresses",      icon: locationIcon   },
  { id: "points",    label: "Earning Points", icon: rewardIcon     },
  { id: "to-review", label: "My Reviews",     icon: reviewIcon     },
];

export default function ProfileSidebar({ user, activeTab, setActiveTab, onAvatarUpdate }) {
  const { logout } = useAuth();
  const navigate   = useNavigate();
  const fileRef    = useRef(null);

  const [avatarSrc,   setAvatarSrc]   = useState(null);
  const [uploading,   setUploading]   = useState(false);

  // Sync avatar whenever user prop changes (e.g. after fetchProfile)
  useEffect(() => {
    const url = makeUrl(user?.avatar);
    setAvatarSrc(url || defaultAvatar);
  }, [user?.avatar]);

  // ── Upload avatar to server ────────────────────────────
  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Instant preview
    const preview = URL.createObjectURL(file);
    setAvatarSrc(preview);

    const formData = new FormData();
    formData.append("avatar", file);

    setUploading(true);
    try {
      const res = await API.post("/upload/avatar", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      if (res.data?.success && res.data?.imageUrl) {
        const serverUrl = makeUrl(res.data.imageUrl);
        setAvatarSrc(serverUrl);
        // Tell parent (ProfilePage) to re-fetch profile so auth context is updated
        if (onAvatarUpdate) onAvatarUpdate();
      }
    } catch (err) {
      console.error("Avatar upload failed:", err);
      alert("Profile picture update nahi hui. Please try again.");
      setAvatarSrc(makeUrl(user?.avatar) || defaultAvatar);
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };

  const handleLogout = async () => {
    try { await API.post("/auth/logout"); } catch (_) {}
    logout();
    navigate("/login");
  };

  return (
    <div className="profile-sidebar card-light sidebar-elevated">
      {/* ── Avatar ── */}
      <div className="sidebar-top">
        <div
          className="avatar-wrap"
          onClick={() => !uploading && fileRef.current?.click()}
          title="Change profile picture"
          style={{ cursor: uploading ? "not-allowed" : "pointer", position: "relative" }}
        >
          <img
            src={avatarSrc || defaultAvatar}
            alt={user?.name || "User"}
            className="profile-avatar"
            onError={(e) => { e.target.src = defaultAvatar; }}
          />
          {uploading && (
            <div className="avatar-uploading-overlay">
              <span>⏳</span>
            </div>
          )}
          <div className="avatar-edit-badge">📷</div>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            style={{ display: "none" }}
          />
        </div>

        <div className="sidebar-user">
          <div className="hello-text">Hello</div>
          <h3 className="sidebar-username">{user?.name || "User"}</h3>
          <p className="sidebar-email">{user?.email || ""}</p>
          {(user?.points ?? 0) > 0 && (
            <p className="sidebar-points">🏆 {user.points} pts</p>
          )}
        </div>
      </div>

      {/* ── Menu ── */}
      <ul className="account-menu">
        {MENU.map((item) => (
          <li
            key={item.id}
            className={activeTab === item.id ? "active" : ""}
            onClick={() => setActiveTab(item.id)}
          >
            <img src={item.icon} alt={item.label} className="menu-icon" />
            {item.label}
          </li>
        ))}

        <li className="logout-item" onClick={handleLogout}>
          <img src={logoutIcon} alt="Logout" className="menu-icon" />
          Logout
        </li>
      </ul>
    </div>
  );
}
